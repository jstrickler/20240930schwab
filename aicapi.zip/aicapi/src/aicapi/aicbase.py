from dataclasses import dataclass, field
import dataclasses as DC
import lxml.etree as et
import requests

# API docs
# https://api.artic.edu/docs

@dataclass
class AICBase:
    AIC_BASE_URL = "https://api.artic.edu/api/v1"

    def _get_data(self, url):
        response = requests.get(url)
        if response.status_code == requests.codes.not_found:
            raise ValueError(f"Resource not found")
        return response.json()['data']

    def as_dict(self):
        return DC.asdict(self)
    
    def as_xml(self):
        root = et.Element(type(self).__name__.lower())
        for key, value in self.as_dict().items():
            et.SubElement(root, key.lower()).text = str(value)
        return et.tostring(root, pretty_print=True).decode()
