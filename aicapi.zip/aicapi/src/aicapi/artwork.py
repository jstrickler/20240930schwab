from dataclasses import dataclass, field
import lxml.etree as et
from aicapi.aicbase import AICBase

# sample endpoint
# https://api.artic.edu/api/v1/artworks/4

@dataclass
class Artwork(AICBase):
    id: int
    title: str = field(init=False)
    artist: str = field(init=False)
    medium: str = field(init=False)

    def __init__(self, artwork_id):
        url = f"{self.AIC_BASE_URL}/artworks/{artwork_id}"
        data = self._get_data(url)
        self.id = data['id']
        self.title = data.get('title')
        self.artist = data.get('artist_title')
        self.medium = data.get('medium_display')
