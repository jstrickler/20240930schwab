from pprint import pprint
from argparse import ArgumentParser

from aicapi.artwork import Artwork
from aicapi.agent import Agent

arg_parser = ArgumentParser(description="AIC API interface")
arg_parser.add_argument("--artist_id", "-ar", help="artist ID")
arg_parser.add_argument("--agent_id", "-ag", help="agent ID")

args = arg_parser.parse_args()

try:
    if args.agent_id:
        a = Agent(args.agent_id)
    elif args.artist_id:
        a = Artwork(args.artist_id)
except ValueError as err:
    print(err)
else:
    print(a)
    print()
    print(a.as_dict())
    print()
    print(a.as_xml())