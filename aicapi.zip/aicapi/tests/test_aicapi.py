import pytest

from aicapi.scripts import sample_function


def test_aicapi_has_sample_function():
    assert sample_function() is None  # no return value
