import pytest

from articapi.scripts import sample_function


def test_articapi_has_sample_function():
    assert sample_function() is None  # no return value
