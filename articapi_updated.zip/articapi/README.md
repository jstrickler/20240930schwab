README for ARTIC API

Describe your project here.

Describe how to install it.

Describe how to use it.

Last Updated 2024
