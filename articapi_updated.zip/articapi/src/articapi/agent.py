from dataclasses import dataclass, field
import dataclasses as DC
import lxml.etree as et

from articapi.articbase import ARTICBase

# sample endpoint
# https://api.artic.edu/api/v1/agents/30979

@dataclass
class Agent(ARTICBase):
    id: int
    title: str = field(init=False)
    is_artist: str = field(init=False)

    def __init__(self, agent_id: int):
        url = f"{self.ARTIC_BASE_URL}/agents/{agent_id}"
        data = self._get_data(url)
        self.id = data['id']
        self.title = data.get('title')
        self.is_artist = data.get('is_artist')
