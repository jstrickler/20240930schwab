from dataclasses import dataclass, field
from functools import partial
import lxml.etree as et
from articapi.articbase import ARTICBase

# sample endpoint
# https://api.artic.edu/api/v1/artworks/4

no_init = partial(field, init=False)

@dataclass
class Artwork(ARTICBase):
    id: int
    title: str = no_init()
    artist: str = field(init=False)
    medium: str = field(init=False)

    def __init__(self, artwork_id):
        url = f"{self.ARTIC_BASE_URL}/artworks/{artwork_id}"
        data = self._get_data(url)
        self.id = data['id']
        self.title = data.get('title')
        self.artist = data.get('artist_title')
        self.medium = data.get('medium_display')
