from pprint import pprint
from argparse import ArgumentParser
from articapi.artwork import Artwork
from articapi.agent import Agent

def main():
    args = parse_args()
    print(f"{args = }")

    try:
        if args.agent_id:
            a = Agent(args.agent_id)
        elif args.artist_id:
            a = Artwork(args.artist_id)
    except ValueError as err:
        print(err)
    else:
        if args.raw:
            print(a)
        elif args.dict:
            pprint(a.as_dict())
        elif args.xml:
            print(a.as_xml())
        else:
            print(a)  # default

def parse_args():
    arg_parser = ArgumentParser(description="AIC API interface")

    resource_group = arg_parser.add_argument_group("Resource Types")
    exclusive_resource_group = resource_group.add_mutually_exclusive_group(required=True)
    exclusive_resource_group.add_argument("--agent_id", "-ag", help="agent ID")
    exclusive_resource_group.add_argument("--artist_id", "-ar", help="artist ID")

    output_group = arg_parser.add_argument_group("Output Types")
    exclusive_output_group = output_group.add_mutually_exclusive_group()
    exclusive_output_group.add_argument("--raw", "-r", action="store_true", help="Raw object")
    exclusive_output_group.add_argument("--xml", "-x", action="store_true", help="XML")
    exclusive_output_group.add_argument("--dict", "-d", action="store_true", help="Dictionary")

    args = arg_parser.parse_args()
    return args

if __name__ == "__main__":
    main()