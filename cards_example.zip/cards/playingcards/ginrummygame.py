from playingcards.cardgamebase import CardGameBase
from playingcards.cardplayer import CardPlayer

class GinRummyGame(CardGameBase):
    MAX_PLAYERS: int = 2


if __name__ == '__main__':
    from playingcards.ginrummystrategy import GinRummyStrategy
    from playingcards.cardplayer import CardPlayer
    game = GinRummyGame(GinRummyStrategy())
    for player in "Nelly Andy".split():
        game.add_player(CardPlayer(player))

    print(game.players)
    print(game)
    print(repr(game))

