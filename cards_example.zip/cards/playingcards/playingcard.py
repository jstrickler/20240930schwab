from typing import Union

class PlayingCard:
    def __init__(self, rank: str, suit: str, value: Union[int, None]):
        # read-only data/properties
        self._rank = rank
        self._suit = suit

        # read-write data/properties
        self.value = value

    @property
    def rank(self):
        return self._rank

    @property
    def suit(self):
        return self._suit

    @property
    def value(self):
        return self._card_value

    @value.setter
    def value(self, card_value: int):
        if isinstance(card_value, (int, type(None))):
            self._card_value = card_value
        else:
            raise TypeError("Card value must be an int")

    def __str__(self):
        return f"{self.rank}-{self.suit}({self.value})"

    def __repr__(self):
        suit = None if self.suit is None else f"'{self.suit}'"
        return f"Card('{self.rank}', {suit}, {self.value})"

if __name__ == '__main__':
    ranks = '2 3 4 5 6 7 8 9 10 J Q K A'.split()
    values = 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 1
    for card_rank, card_value in zip(ranks, values):
        c = PlayingCard(card_rank, 'clubs', card_value)
        print(c.rank, c.suit, c.value)
