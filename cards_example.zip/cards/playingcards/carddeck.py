import random
from playingcard import PlayingCard

class CardDeck:

    # SUITS: list[str] = 'Clubs Diamonds Hearts Spades'.split()
    SUITS: list[str] = ["\u2663", "\u2666", "\u2665", "\u2660"]
    RANKS: list[str] = 'A 2 3 4 5 6 7 8 9 10 J Q K'.split()
    # default values for generic deck
    VALUES: list[int] = 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10

    def __init__(self, dealer) -> None:
        self.dealer = dealer
        self._make_deck()

    def _make_deck(self) -> None:
        self._cards = []
        for suit in self.SUITS:
            for rank, value in zip(self.RANKS, self.VALUES):
                card  = PlayingCard(rank, suit, value)
                self._cards.append(card)

    @property
    def cards(self):
        return self._cards

    @property
    def dealer(self):
        return self._dealer

    @dealer.setter
    def dealer(self, value: str):
        if isinstance(value, str):
            self._dealer = value
        else:
            raise TypeError("Dealer must be a string")

    def draw(self):
        return self._cards.pop()

    def shuffle(self):
        random.shuffle(self._cards)

    def __repr__(self):
        class_name = type(self).__name__
        return f"{class_name}('{self.dealer}')"

    def __str__(self):
        class_name = type(self).__name__
        return f"{class_name}-{len(self)}"

    def __len__(self):
        return len(self.cards)

if __name__ == '__main__':
    d = CardDeck("Catherine")
    print(d.cards)
    print(d, repr(d))
