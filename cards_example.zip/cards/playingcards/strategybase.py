from abc import ABCMeta, abstractmethod

class StrategyBase:
    pass


