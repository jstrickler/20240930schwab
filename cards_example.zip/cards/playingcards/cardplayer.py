from hand import Hand

class CardPlayer:
    def __init__(self, player_name: str):
        self.player_name = player_name
        self.hand = Hand()

    @property
    def player_name(self):
        return self._player_name

    @player_name.setter
    def player_name(self, player_name: str):
        if isinstance(player_name, str):
            self._player_name = player_name
        else:
            raise TypeError("Player name must be a string")

    def __str__(self):
        return f"{self.player_name}-{self.hand}"

    def __repr__(self):
        my_type = type(self).__name__
        return f"{my_type}('{self.player_name}')"
