from playingcard import PlayingCard


class Hand:
    def __init__(self):
        self._cards = []

    def add(self, card: PlayingCard):
        self._cards.append(card)

    def discard(self, card: PlayingCard):
        self._cards.remove(card)

    @property
    def cards(self):
        return tuple(self._cards)


