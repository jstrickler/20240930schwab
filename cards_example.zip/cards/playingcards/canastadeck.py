from typing import Any
from carddeck import CardDeck
from playingcard import PlayingCard

class CanastaDeck(CardDeck):
    VALUES: Any = 20, 20, None, 5, 5, 5, 5, 10, 10, 10, 10, 10, 10, 20

    def _make_deck(self):
        super()._make_deck()
        for i in range(2):
            joker = PlayingCard('JK', "\U0001F0CF", 50)
            self._cards.append(joker)

if __name__ == '__main__':
    j = CanastaDeck('Connie')
    j.shuffle()
    print(j.cards)
    print(j, repr(j))
