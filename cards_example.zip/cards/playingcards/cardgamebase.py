from abc import ABCMeta, abstractmethod
from playingcards.cardplayer import CardPlayer
from playingcards.strategybase import StrategyBase

class CardGameBase(metaclass=ABCMeta):
    MAX_PLAYERS: int = 4

    def __init__(self, strategy: StrategyBase):
        self._strategy = strategy
        self._players = []

    def add_player(self, player: CardPlayer) -> None:
        if len(self._players) < self.MAX_PLAYERS:
            self._players.append(player)
        else:
            raise ValueError(f"Maximum {self.MAX_PLAYERS} players")

    @property
    def players(self):
        return self._players

    def _get_class_name(self):
        return type(self).__name__

    def __str__(self):
        class_name = self._get_class_name()
        return f"<{class_name}[{','.join(self.players)}]>"

    def __repr__(self):
        class_name = self._get_class_name()
        strategy_name = type(self._strategy).__name__
        return f"{class_name}({strategy_name}())"

if __name__ == '__main__':
    from playingcards.ginrummystrategy import GinRummyStrategy
    game = CardGameBase(GinRummyStrategy)
    for name in 'John Paul George Ringo Stuart'.split():
        player = CardPlayer(name)
        try:
            game.add_player(player)
        except ValueError as err:
            print("ERROR:", err)

    print(game._players)
