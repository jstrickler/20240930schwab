import os
print(os.getenv('PYTHONPATH'))
from playingcards.carddeck import CardDeck


class GinRummyDeck(CardDeck):
    VALUES: list[int] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]

if __name__ == '__main__':
    d = GinRummyDeck("Gina")
    d.shuffle()
    print(d.cards)
    print(d, repr(d))
    for _ in range(10):
        print(d.draw())
