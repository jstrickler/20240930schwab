from typing import Optional
from playingcards.strategybase import StrategyBase
from playingcards.playingcard import PlayingCard
from playingcards.hand import Hand

class GinRummyStrategy(StrategyBase):

    def get_discard(self, hand: Hand) -> Optional[PlayingCard]:
        """
        Figure out best hand and return card to discard
        :param hand:
        :return:
        """
        runs = self._find_runs()
        sets = self._find_sets()


        return None

